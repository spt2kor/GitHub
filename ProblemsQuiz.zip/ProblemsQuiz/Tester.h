#pragma once

void runStandardTestCase();
