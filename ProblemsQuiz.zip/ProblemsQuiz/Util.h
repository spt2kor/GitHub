#pragma once

double PrecisionCorrection(double no);

double RoundUp(double no);

